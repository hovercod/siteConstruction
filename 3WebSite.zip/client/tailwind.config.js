/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#2466a3",
        accent: "#e1e8ee",
        dark: "#222f3e",
      },
    },
  },
  plugins: [],
};