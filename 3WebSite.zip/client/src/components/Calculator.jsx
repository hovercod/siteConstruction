import React, { useState } from "react";
import axios from "axios";

export default function Calculator() {
  // Состояния для площади, описания, контакта, изображений и других параметров
  const [area, setArea] = useState("");
  const [description, setDescription] = useState("");
  const [contact, setContact] = useState("");
  const [images, setImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [showContact, setShowContact] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  // Обработка выбора изображений
  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setImages(files);
    setImagePreviews(files.map(file => URL.createObjectURL(file)));
  };

  // Отправка формы
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setResult(null);

    // Показываем поле контакта только после первого шага
    if (!showContact) {
      setShowContact(true);
      return;
    }

    if (!contact) {
      setError("Пожалуйста, введите телефон или email.");
      return;
    }

    // Формируем данные для отправки, включая изображения
    const formData = new FormData();
    formData.append("area", area);
    formData.append("description", description);
    formData.append("contact", contact);
    images.forEach((img, idx) => formData.append("images", img));

    try {
      // Отправляем POST-запрос на сервер с типом multipart/form-data
      const res = await axios.post(
        "http://localhost:5000/api/calc/estimate",
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setResult(res.data);
    } catch (e) {
      setError("Ошибка сервера. Попробуйте позже.");
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded shadow">
      <h2 className="text-2xl font-bold mb-4 text-primary">AI Cost Calculator</h2>
      <div className="mb-2 text-gray-700 text-sm">
        Получите предварительную оценку стоимости вашего проекта. Заполните данные для бесплатного расчёта.
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          {/* Поле для ввода площади */}
          <label className="block mb-1">Площадь проекта (кв. футы):</label>
          <input
            type="number"
            value={area}
            onChange={e => setArea(e.target.value)}
            className="border rounded p-2 w-full"
            disabled={showContact}
            required
          />
        </div>
        <div>
          {/* Поле для описания проекта */}
          <label className="block mb-1">Описание проекта:</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            className="border rounded p-2 w-full"
            rows={4}
            placeholder="Опишите ваш проект, пожелания и детали."
            disabled={showContact}
            required
          />
        </div>
        {/* Раздел для загрузки фотографий */}
        <div>
          <label className="block mb-1">Прикрепить фотографии:</label>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleImageChange}
            disabled={showContact}
          />
          {/* Превью выбранных изображений */}
          <div className="flex mt-2 gap-2 flex-wrap">
            {imagePreviews.map((src, idx) => (
              <img
                key={idx}
                src={src}
                alt={`preview-${idx}`}
                style={{ width: 80, height: 80, objectFit: "cover", borderRadius: 8, border: "1px solid #ccc" }}
              />
            ))}
          </div>
        </div>
        {showContact && (
          <div>
            {/* Поле для контакта */}
            <label className="block mb-1">Телефон или email (обязательно):</label>
            <input
              type="text"
              value={contact}
              onChange={e => setContact(e.target.value)}
              className="border rounded p-2 w-full"
              required
            />
            <div className="text-xs text-gray-500 mt-1">
              Ваши контактные данные будут использованы только для связи.<br />
              <b>Этот расчёт предварительный и не является юридически обязывающим для сторон.</b>
            </div>
          </div>
        )}
        {/* Кнопка отправки */}
        <button
          type="submit"
          className="bg-primary text-white px-4 py-2 rounded"
        >
          {!showContact ? "Рассчитать" : "Получить результат"}
        </button>
        {/* Вывод ошибок */}
        {error && <div className="text-red-500 mt-2">{error}</div>}
      </form>
      {/* Блок с результатом расчёта */}
      {result && (
        <div className="mt-6 p-4 border rounded bg-accent">
          <div className="font-bold mb-2">Результат:</div>
          <div>Площадь: <b>{area} кв.фут</b></div>
          <div>Описание: <b>{description}</b></div>
          <div>Оценочная стоимость: <b>{result.price} USD</b></div>
          <div>Срок выполнения: <b>{result.estimatedDays} дней</b></div>
          <div className="text-xs text-gray-600 mt-2">
            {result.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
}