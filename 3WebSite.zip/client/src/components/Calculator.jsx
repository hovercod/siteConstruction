import React, { useState } from "react";
import axios from "axios";

export default function Calculator() {
  const [area, setArea] = useState("");
  const [serviceType, setServiceType] = useState("painting");
  const [description, setDescription] = useState("");
  const [contact, setContact] = useState("");
  const [showContact, setShowContact] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setResult(null);

    if (!showContact) {
      setShowContact(true);
      return;
    }

    if (!contact) {
      setError("Please enter your phone or email.");
      return;
    }

    try {
      // Временно просто отправляем всё на backend
      const res = await axios.post("http://localhost:5000/api/calc/estimate", {
        area,
        serviceType,
        description, // <-- новое поле
        contact
      });
      setResult(res.data);
    } catch (e) {
      setError("Server error. Please try again later.");
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded shadow">
      <h2 className="text-2xl font-bold mb-4 text-primary">AI Cost Calculator</h2>
      <div className="mb-2 text-gray-700 text-sm">
        Get a preliminary estimate for your project. Enter your details to receive a free quote.
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Service type:</label>
          <select
            value={serviceType}
            onChange={e => setServiceType(e.target.value)}
            className="border rounded p-2 w-full"
            disabled={showContact}
          >
            <option value="painting">Painting</option>
            <option value="tile">Tiling</option>
            <option value="flooring">Flooring</option>
            <option value="plumbing">Plumbing</option>
            <option value="electrical">Electrical</option>
            <option value="general">General construction</option>
          </select>
        </div>
        <div>
          <label className="block mb-1">Project area (sq.ft):</label>
          <input
            type="number"
            value={area}
            onChange={e => setArea(e.target.value)}
            className="border rounded p-2 w-full"
            disabled={showContact}
            required
          />
        </div>
        <div>
          <label className="block mb-1">Project description:</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            className="border rounded p-2 w-full"
            rows={4}
            placeholder="Describe your project, requirements, or any details you'd like to share with us."
            disabled={showContact}
            required
          />
        </div>
        {showContact && (
          <div>
            <label className="block mb-1">Phone or email (required):</label>
            <input
              type="text"
              value={contact}
              onChange={e => setContact(e.target.value)}
              className="border rounded p-2 w-full"
              required
            />
            <div className="text-xs text-gray-500 mt-1">
              Your contact will only be used to reach out to you.<br />
              <b>This calculation is preliminary and not legally binding for both parties.</b>
            </div>
          </div>
        )}
        <button
          type="submit"
          className="bg-primary text-white px-4 py-2 rounded"
        >
          {!showContact ? "Calculate" : "Get Result"}
        </button>
        {error && <div className="text-red-500 mt-2">{error}</div>}
      </form>
      {result && (
        <div className="mt-6 p-4 border rounded bg-accent">
          <div className="font-bold mb-2">Result:</div>
          <div>Service: <b>{serviceType}</b></div>
          <div>Area: <b>{area} sq.ft</b></div>
          <div>Description: <b>{description}</b></div>
          <div>Estimated cost: <b>{result.price} USD</b></div>
          <div>Estimated time: <b>{result.estimatedDays} days</b></div>
          <div className="text-xs text-gray-600 mt-2">
            {result.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
}