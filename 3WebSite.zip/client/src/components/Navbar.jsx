import React from "react";
import { NavLink } from "react-router-dom";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/calculator", label: "Calculator" },
  { to: "/about", label: "About" },
  { to: "/team", label: "Team" },
  { to: "/gallery", label: "Gallery" },
  { to: "/reviews", label: "Reviews" },
  { to: "/contacts", label: "Contacts" },
];

export default function Navbar() {
  return (
    <nav className="bg-primary text-white py-3 mb-6 shadow">
      <div className="max-w-5xl mx-auto flex gap-4 flex-wrap justify-center">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              "px-3 py-1 rounded transition " +
              (isActive ? "bg-white text-primary font-semibold" : "hover:bg-blue-700")
            }
            end={item.to === "/"}
          >
            {item.label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}