import React from "react";

const reviews = [
  {
    name: "Olga S.",
    text: "Thank you for the excellent bathroom renovation! Everything was done quickly and neatly.",
  },
  {
    name: "Dmitry L.",
    text: "I appreciated the personalized approach and transparent estimate.",
  },
  {
    name: "Svetlana K.",
    text: "The work was high quality, the team is great!",
  },
];

export default function Reviews() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">Customer Reviews</h1>
      <div className="space-y-6">
        {reviews.map((r, i) => (
          <div key={i} className="bg-white rounded shadow p-4">
            <div className="font-semibold mb-1">{r.name}</div>
            <div className="italic">"{r.text}"</div>
          </div>
        ))}
      </div>
    </div>
  );
}