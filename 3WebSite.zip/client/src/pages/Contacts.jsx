import React, { useState } from "react";

export default function Contacts() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", message: "" });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
    // Integrate with backend to send the form if needed.
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">Contacts</h1>
      <div className="mb-6">
        <div>Phone: <a href="tel:+12065551234" className="text-primary">+1 (206) 555-1234</a></div>
        <div>E-mail: <a href="mailto:25realhome@gmail.com" className="text-primary">25realhome@gmail.com</a></div>
        <div>Services across Washington State</div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-3 max-w-md">
        <div>
          <input
            type="text"
            name="name"
            placeholder="Your name"
            value={form.name}
            onChange={handleChange}
            className="border rounded p-2 w-full"
          />
        </div>
        <div>
          <input
            type="text"
            name="phone"
            placeholder="Phone"
            value={form.phone}
            onChange={handleChange}
            className="border rounded p-2 w-full"
          />
        </div>
        <div>
          <textarea
            name="message"
            placeholder="Your message"
            value={form.message}
            onChange={handleChange}
            className="border rounded p-2 w-full"
            rows={3}
          />
        </div>
        <button type="submit" className="bg-primary text-white px-4 py-2 rounded">
          Send
        </button>
        {sent && <div className="text-green-600 mt-2">Thank you! We will contact you soon.</div>}
      </form>
      <div className="mt-8">
        <div className="w-full h-64 bg-accent flex items-center justify-center text-gray-400 rounded">
          Office map (coming soon)
        </div>
      </div>
    </div>
  );
}