import React from "react";

const team = [
  { name: "Andrey Ivanov", role: "General Manager", photo: "" },
  { name: "Maria Petrova", role: "Designer", photo: "" },
  { name: "Alexey Smirnov", role: "All-round Specialist", photo: "" },
  { name: "Victor Kim", role: "Plumber", photo: "" },
  { name: "Sergey Vasiliev", role: "Electrician", photo: "" },
];

export default function Team() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">Our Team</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {team.map((person) => (
          <div key={person.name} className="bg-white rounded shadow p-4 flex flex-col items-center">
            <div className="w-24 h-24 bg-accent rounded-full mb-3 flex items-center justify-center text-2xl">
              {person.photo ? (
                <img src={person.photo} alt={person.name} className="rounded-full" />
              ) : (
                <span role="img" aria-label="avatar">👷‍♂️</span>
              )}
            </div>
            <div className="font-semibold">{person.name}</div>
            <div className="text-sm text-gray-600">{person.role}</div>
          </div>
        ))}
      </div>
    </div>
  );
}