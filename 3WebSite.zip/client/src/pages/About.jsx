import React from "react";

export default function About() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">About Us</h1>
      <p>
        UnionBuilder’s is a team of licensed professionals with years of experience in the Washington construction market.<br />
        We handle any task — from cosmetic repairs to comprehensive turnkey projects.
      </p>
      <div className="mt-4">
        <h2 className="text-xl font-semibold mb-1">Our Mission</h2>
        <p>To make quality renovation accessible and transparent for every client.</p>
      </div>
      <div className="mt-4">
        <h2 className="text-xl font-semibold mb-1">Licenses & Guarantees</h2>
        <ul className="list-disc pl-6">
          <li>Washington State License #12345678</li>
          <li>Liability insurance</li>
          <li>Up to 3 years warranty on work</li>
        </ul>
      </div>
    </div>
  );
}