import React from "react";

const services = [
  {
    title: "Painting",
    desc: "Wall, ceiling, and facade painting, surface preparation.",
  },
  {
    title: "Tiling",
    desc: "Installation of ceramic tiles, mosaics, porcelain tiles in bathrooms, kitchens, and more.",
  },
  {
    title: "Flooring",
    desc: "Laminate, parquet, and self-leveling floor installation.",
  },
  {
    title: "Plumbing",
    desc: "Replacement and installation of plumbing, pipework, filter installation.",
  },
  {
    title: "Electrical",
    desc: "Wiring, installation of sockets, lighting, circuit breakers.",
  },
  {
    title: "Turnkey Renovation",
    desc: "Comprehensive apartment and house renovation with materials and design selection.",
  },
];

export default function Services() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">Our Services</h1>
      <ul className="space-y-5">
        {services.map((s) => (
          <li key={s.title} className="border-b pb-3">
            <strong>{s.title}:</strong> {s.desc}
          </li>
        ))}
      </ul>
    </div>
  );
}