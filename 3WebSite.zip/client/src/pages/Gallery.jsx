import React from "react";

const images = [
  { src: "", before: true, desc: "Kitchen — before" },
  { src: "", before: false, desc: "Kitchen — after" },
  { src: "", before: true, desc: "Bathroom — before" },
  { src: "", before: false, desc: "Bathroom — after" },
];

export default function Gallery() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-primary">Project Gallery</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {images.map((img, i) => (
          <div key={i} className="bg-white rounded shadow p-2 flex flex-col items-center">
            <div className="w-32 h-24 bg-accent flex items-center justify-center rounded mb-2">
              {img.src ? (
                <img src={img.src} alt={img.desc} className="object-cover w-full h-full rounded" />
              ) : (
                <span className="text-gray-400">Photo</span>
              )}
            </div>
            <span className="text-sm">{img.desc}</span>
          </div>
        ))}
      </div>
    </div>
  );
}