import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-4 text-primary">UnionBuilder’s</h1>
      <p className="mb-6 text-lg">
        Your trusted partner for property renovation and remodeling in Washington State.
      </p>
      <Link to="/calculator">
        <button className="bg-primary text-white px-6 py-2 rounded text-lg mb-8 hover:bg-blue-800">
          Calculate Project Cost
        </button>
      </Link>
      <section className="mb-8">
        <h2 className="text-2xl font-semibold mb-2">Our Advantages</h2>
        <ul className="list-disc pl-6 text-lg">
          <li>Licensed professionals</li>
          <li>Quality guarantee and transparent estimates</li>
          <li>Only proven materials</li>
          <li>Personalized approach to every client</li>
        </ul>
      </section>
      <section>
        <h2 className="text-2xl font-semibold mb-2">Services</h2>
        <ul className="list-disc pl-6">
          <li>Turnkey renovation</li>
          <li>Painting, tiling, flooring</li>
          <li>Plumbing and electrical work</li>
          <li>Design and planning</li>
        </ul>
        <Link to="/services" className="text-primary underline block mt-2">Learn more about services</Link>
      </section>
    </div>
  );
}