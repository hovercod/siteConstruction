const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const app = express();
const PORT = 5000;

// Хранилище для загруженных файлов (используем хранение в памяти)
const storage = multer.memoryStorage();
const upload = multer({ storage });

app.use(cors());
app.use(express.json());

// Эндпоинт для получения расчёта стоимости с поддержкой фото
app.post("/api/calc/estimate", upload.array("images"), (req, res) => {
  // Получаем данные из формы
  const { area, description, contact } = req.body;
  // req.files — массив загруженных файлов

  // Для отладки: информация о загруженных файлах (имя, размер, тип)
  const filesInfo = req.files?.map(f => ({
    originalname: f.originalname,
    size: f.size,
    mimetype: f.mimetype
  }));

  // Примитивная логика расчёта стоимости —
  // ставка всегда 12 (ИИ позже сможет определять тип услуги сам)
  const baseRate = 12;
  const price = Math.round(Number(area) * baseRate);
  const estimatedDays = Math.ceil(Number(area) / 500) + 1;

  // Возвращаем результат расчёта
  res.json({
    price,
    estimatedDays,
    description,
    files: filesInfo, // информация о фото (можно убрать на проде)
    disclaimer: "Этот расчёт предварительный. Итоговая цена может измениться после обсуждения."
  });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});